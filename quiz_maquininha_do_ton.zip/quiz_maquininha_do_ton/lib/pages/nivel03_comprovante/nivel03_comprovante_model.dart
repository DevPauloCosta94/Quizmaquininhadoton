import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'nivel03_comprovante_widget.dart' show Nivel03ComprovanteWidget;
import 'package:flutter/material.dart';

class Nivel03ComprovanteModel
    extends FlutterFlowModel<Nivel03ComprovanteWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
