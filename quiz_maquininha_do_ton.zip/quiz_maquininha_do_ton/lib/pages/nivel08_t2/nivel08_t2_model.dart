import '/flutter_flow/flutter_flow_util.dart';
import 'nivel08_t2_widget.dart' show Nivel08T2Widget;
import 'package:flutter/material.dart';

class Nivel08T2Model extends FlutterFlowModel<Nivel08T2Widget> {
  ///  Local state fields for this page.

  bool musicEnabled = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
