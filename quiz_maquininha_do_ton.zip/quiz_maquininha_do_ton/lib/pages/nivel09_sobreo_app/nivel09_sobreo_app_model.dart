import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'nivel09_sobreo_app_widget.dart' show Nivel09SobreoAppWidget;
import 'package:flutter/material.dart';

class Nivel09SobreoAppModel extends FlutterFlowModel<Nivel09SobreoAppWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
