import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'nivel10_contatos_widget.dart' show Nivel10ContatosWidget;
import 'package:flutter/material.dart';

class Nivel10ContatosModel extends FlutterFlowModel<Nivel10ContatosWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
