import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'n_ivel02_pix_widget.dart' show NIvel02PixWidget;
import 'package:flutter/material.dart';

class NIvel02PixModel extends FlutterFlowModel<NIvel02PixWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
