import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'nivel00_inicio_widget.dart' show Nivel00InicioWidget;
import 'package:flutter/material.dart';

class Nivel00InicioModel extends FlutterFlowModel<Nivel00InicioWidget> {
  ///  Local state fields for this page.

  bool musicEnabled = false;

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Custom Action - initializeLevels] action in Play widget.
  List<LevelStruct>? generatedLevels;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
