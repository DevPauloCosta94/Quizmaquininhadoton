import '/flutter_flow/flutter_flow_util.dart';
import 'nivel06_t3_smart_widget.dart' show Nivel06T3SmartWidget;
import 'package:flutter/material.dart';

class Nivel06T3SmartModel extends FlutterFlowModel<Nivel06T3SmartWidget> {
  ///  Local state fields for this page.

  bool musicEnabled = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
