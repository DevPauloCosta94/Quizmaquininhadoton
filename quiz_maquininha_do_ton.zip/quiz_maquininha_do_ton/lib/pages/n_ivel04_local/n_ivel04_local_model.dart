import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'n_ivel04_local_widget.dart' show NIvel04LocalWidget;
import 'package:flutter/material.dart';

class NIvel04LocalModel extends FlutterFlowModel<NIvel04LocalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
