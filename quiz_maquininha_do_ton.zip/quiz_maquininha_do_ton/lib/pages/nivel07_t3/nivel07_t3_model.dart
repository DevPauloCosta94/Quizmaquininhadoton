import '/flutter_flow/flutter_flow_util.dart';
import 'nivel07_t3_widget.dart' show Nivel07T3Widget;
import 'package:flutter/material.dart';

class Nivel07T3Model extends FlutterFlowModel<Nivel07T3Widget> {
  ///  Local state fields for this page.

  bool musicEnabled = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
