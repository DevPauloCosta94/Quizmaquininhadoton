import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'nivel01_perfil_widget.dart' show Nivel01PerfilWidget;
import 'package:flutter/material.dart';

class Nivel01PerfilModel extends FlutterFlowModel<Nivel01PerfilWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
