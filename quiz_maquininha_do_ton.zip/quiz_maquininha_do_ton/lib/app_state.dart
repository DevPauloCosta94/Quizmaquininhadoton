import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _playerName = prefs.getString('ff_playerName') ?? _playerName;
    });
    _safeInit(() {
      _isDarkMode = prefs.getBool('ff_isDarkMode') ?? _isDarkMode;
    });
    _safeInit(() {
      _lastAchievedLevel =
          prefs.getInt('ff_lastAchievedLevel') ?? _lastAchievedLevel;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  String _playerName = 'player1';
  String get playerName => _playerName;
  set playerName(String value) {
    _playerName = value;
    prefs.setString('ff_playerName', value);
  }

  bool _isDarkMode = false;
  bool get isDarkMode => _isDarkMode;
  set isDarkMode(bool value) {
    _isDarkMode = value;
    prefs.setBool('ff_isDarkMode', value);
  }

  int _levelsCount = 5;
  int get levelsCount => _levelsCount;
  set levelsCount(int value) {
    _levelsCount = value;
  }

  int _lastAchievedLevel = 0;
  int get lastAchievedLevel => _lastAchievedLevel;
  set lastAchievedLevel(int value) {
    _lastAchievedLevel = value;
    prefs.setInt('ff_lastAchievedLevel', value);
  }

  List<PlayerStruct> _currentPlayers = [];
  List<PlayerStruct> get currentPlayers => _currentPlayers;
  set currentPlayers(List<PlayerStruct> value) {
    _currentPlayers = value;
  }

  void addToCurrentPlayers(PlayerStruct value) {
    currentPlayers.add(value);
  }

  void removeFromCurrentPlayers(PlayerStruct value) {
    currentPlayers.remove(value);
  }

  void removeAtIndexFromCurrentPlayers(int index) {
    currentPlayers.removeAt(index);
  }

  void updateCurrentPlayersAtIndex(
    int index,
    PlayerStruct Function(PlayerStruct) updateFn,
  ) {
    currentPlayers[index] = updateFn(_currentPlayers[index]);
  }

  void insertAtIndexInCurrentPlayers(int index, PlayerStruct value) {
    currentPlayers.insert(index, value);
  }

  List<LevelStruct> _levelsList = [];
  List<LevelStruct> get levelsList => _levelsList;
  set levelsList(List<LevelStruct> value) {
    _levelsList = value;
  }

  void addToLevelsList(LevelStruct value) {
    levelsList.add(value);
  }

  void removeFromLevelsList(LevelStruct value) {
    levelsList.remove(value);
  }

  void removeAtIndexFromLevelsList(int index) {
    levelsList.removeAt(index);
  }

  void updateLevelsListAtIndex(
    int index,
    LevelStruct Function(LevelStruct) updateFn,
  ) {
    levelsList[index] = updateFn(_levelsList[index]);
  }

  void insertAtIndexInLevelsList(int index, LevelStruct value) {
    levelsList.insert(index, value);
  }

  bool _isHapticAllowed = true;
  bool get isHapticAllowed => _isHapticAllowed;
  set isHapticAllowed(bool value) {
    _isHapticAllowed = value;
  }

  bool _isSoundOn = true;
  bool get isSoundOn => _isSoundOn;
  set isSoundOn(bool value) {
    _isSoundOn = value;
  }

  String _musicFile =
      'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3';
  String get musicFile => _musicFile;
  set musicFile(String value) {
    _musicFile = value;
  }

  double _currentMusicVolume = 0.5;
  double get currentMusicVolume => _currentMusicVolume;
  set currentMusicVolume(double value) {
    _currentMusicVolume = value;
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
